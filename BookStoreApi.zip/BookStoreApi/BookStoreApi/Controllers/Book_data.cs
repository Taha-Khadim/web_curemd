﻿namespace BookStoreApi.Controllers
{
    public class Book_data
    {
        public static List<Book_class> books = new List<Book_class>
        {
            new Book_class
            {
                Id = 1,
                Title = "Unlocking Android",
                ImageURL = "https://s3.amazonaws.com/AKIAJC5RLADLUMVRPFDQ.book-thumb-images/ableson.jpg",
                Description = "Unlocking Android: A Developer's Guide provides concise, hands-on instruction for the Android operating system and development tools. This book teaches important architectural concepts in a straightforward writing style and builds on this with practical and useful examples throughout.",
                Authors = new List<string> { "W. Frank Ableson", "Charlie Collins", "Robi Sen" }
            },
            new Book_class
            {
                Id = 2,
                Title = "Android in Action, Second Edition",
                ImageURL = "https://s3.amazonaws.com/AKIAJC5RLADLUMVRPFDQ.book-thumb-images/ableson2.jpg",
                Description = "Android in Action, Second Edition is a comprehensive tutorial for Android developers. Taking you far beyond \"Hello Android,\" this fast-paced book puts you in the driver's seat as you learn important architectural concepts and implementation strategies. You'll master the SDK, build WebKit apps using HTML 5, and even learn to extend or replace Android's built-in features by building useful and intriguing examples.",
                Authors = new List<string> { "W. Frank Ableson", "Robi Sen" }
            },
            new Book_class
            {
                Id = 3,
                Title = "Specification by Example",
                 Description = "Android in Action, Second Edition is a comprehensive tutorial for Android developers. Taking you far beyond \"Hello Android,\" this fast-paced book puts you in the driver's seat as you learn important architectural concepts and implementation strategies. You'll master the SDK, build WebKit apps using HTML 5, and even learn to extend or replace Android's built-in features by building useful and intriguing examples.",
                ImageURL = "https://s3.amazonaws.com/AKIAJC5RLADLUMVRPFDQ.book-thumb-images/adzic.jpg",
                Authors = new List<string> { "Gojko Adzic" }
            },
            new Book_class
            { 
                Id = 4,
                Title = "Flex 3 in Action",
                ImageURL = "https://s3.amazonaws.com/AKIAJC5RLADLUMVRPFDQ.book-thumb-images/ahmed.jpg",
                Authors = [ "Tariq Ahmed with Jon Hirschi", "Faisal Abid" ]
    }
        
        };
        public List<Book_class> GetBooks()
        {
            return books;
        }
        public Book_class GetBook(int id)
        {
            return books.FirstOrDefault(p => p.Id == id);
        }
        public void AddBook(Book_class book)
        {
            books.Add(book);
        }
        public void BookChange(Book_class book)
        {
            var existingProduct = books.FirstOrDefault(p => p.Id == book.Id);

            if (existingProduct != null)
            {
                existingProduct.Title = book.Title;
                existingProduct.Description = book.Description;
                existingProduct.Authors = book.Authors;
                existingProduct.ImageURL = book.ImageURL;
            }
        }
        public void DeleteBook(int id)
        {
            var product = books.First(p => p.Id == id);
            if (product != null)
            {
                books.Remove(product);
            }
        }


    }
}
