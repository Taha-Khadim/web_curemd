﻿using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookStoreApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Book_Controller : ControllerBase
    {
        public Book_data bookdata=new Book_data();
        // GET: api/<Book_Controller>
        [HttpGet]
        public IEnumerable<Book_class> Get()
        {
            return bookdata.GetBooks();
        }

        // GET api/<Book_Controller>/5
        [HttpGet("{id}")]

        public Book_class Get(int id)
        {
            return bookdata.GetBook(id);
        }

        // POST api/<Book_Controller>
        [HttpPost]
        public void Post(Book_class book)
        {
            bookdata.AddBook(book);
        }

        // PUT api/<Book_Controller>/5
        [HttpPut("{id}")]
        public void Put(int id, Book_class book)
        {
            bookdata.BookChange(book);
        }

        // DELETE api/<Book_Controller>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            bookdata.DeleteBook(id);
        }
    }
}
